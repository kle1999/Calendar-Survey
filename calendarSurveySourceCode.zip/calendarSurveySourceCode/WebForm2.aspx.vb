Namespace calendar

Partial Class WebForm2
    Inherits System.Web.UI.Page

    ' Added by hand for access to the form.
    Protected Calendar2 As System.Web.UI.WebControls.Calendar

    ' Added by hand; will create instance in OnInit.
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Dim i As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        ' Create dynamic controls here.
   
        '  TextBox1 = New TextBox()
        '  TextBox1.ID = "TextBox1"
        ' TextBox1.Style("Position") = "Absolute"
        ' TextBox1.Style("Top") = "25px"
        ' TextBox1.Style("Left") = "100px"
        ' Form1.Controls.Add(TextBox1)

        'TextBox2 = New TextBox()
        ' TextBox2.ID = "TextBox2"
        ' TextBox2.Style("Position") = "Absolute"
        'TextBox2.Style("Top") = "60px"
        'TextBox2.Style("Left") = "100px"

        ' Form1.Controls.Add(TextBox2)
        ' CODEGEN: The Web Form Designer requires this method call.
        ' Do not modify it by using the code editor.
        InitializeComponent()

    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            ' Set the initial properties for the text boxes.
       
            '   TextBox1.Text = "TextBox1"
            'TextBox2.Text = "TextBox2"
        End If

        i = 0

    End Sub

    


    Public Sub Calendar1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender


        TextBox1 = New TextBox()
        TextBox1.Attributes("name") = "Day_" & Day(e.Day.Date)
        TextBox1.Text = Day(e.Day.Date)
        TextBox1.ID = "TextBox1" & e.Day.Date.ToShortDateString

        e.Cell.Controls.Clear()
        e.Cell.Controls.Add(TextBox1)



        'TextBox1.Style("Position") = "Absolute"
        'TextBox1.Style("Top") = "25px"
        'TextBox1.Style("Left") = "100px"
        'Form1.Controls.Add(TextBox1)
        'Panel1.Controls.Add(TextBox1)

        'TextBox1 = New TextBox()
        'TextBox1.ID = "TextBox1_" & e.Day.Date

        ' TextBox1.Text = "TextBox1_" & e.Day.Date
        'Form1.Controls.Add(TextBox1)

        'Me.Panel1.Controls.Add(TextBox1)
        '  Form1.Controls.Add(Panel1)


        ' e.Cell.Controls.Add(TextBox1)

        i = i + 1

    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim tbb As TextBox
        tbb = Me.FindControl("Day1")

    End Sub



    Private Sub TextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim txtBoxSender As TextBox
        Dim strTextBoxID As String

        txtBoxSender = CType(sender, TextBox)
        strTextBoxID = txtBoxSender.ID



        Select Case strTextBoxID
            Case "TextBox1_1"
                Label3.Text = "TextBox1 text was changed"

            Case "TextBox2_2"
                Label4.Text = "TextBox2 text was changed"

            Case "TextBox2_3"
                Label4.Text = "TextBox3 text was changed"
        End Select
    End Sub

    Private Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        Dim txtBoxSender As TextBox
        Dim strTextBoxID As String

        Calendar1.Controls(1).FindControl("TextBox_1")

        txtBoxSender = CType(sender, TextBox)
        strTextBoxID = txtBoxSender.ID



        Select Case strTextBoxID
            Case "TextBox1"
                Label3.Text = "TextBox1 text was changed"

            Case "TextBox2"
                Label4.Text = "TextBox2 text was changed"
        End Select
    End Sub
End Class

End Namespace

