﻿
Partial Class footer
    Inherits System.Web.UI.UserControl

End Class
