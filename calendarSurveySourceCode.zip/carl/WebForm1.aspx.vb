

Namespace calendar

Partial Class WebForm1
    Inherits System.Web.UI.Page
    Public WithEvents dynamicTb As TextBox
    Public testTb As TextBox
    Dim i As Integer
    Dim WithEvents LinkButton1 As LinkButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        i = 0
        testTb = New TextBox()
        testTb.ID = "testTb1"
        testTb.Text = "this is a test"

        Me.PlaceHolder1.Controls.Add(testTb)



    End Sub



    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Write("test" & Request("__EVENTARGUMENT").ToString())
    End Sub


    Public Sub Calendar1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender
        i = i + 1
        dynamicTb = New TextBox()
        dynamicTb.ID = i
        dynamicTb.Text = "hello " & i



        LinkButton1 = New LinkButton()
        LinkButton1.Text = "test " & i
        LinkButton1.ID = "testtest" & i


        LinkButton1.Attributes("href") = "javascript:__doPostBack(�ParentControl$LinkButton1�,�" & e.Day.DayNumberText & "�)"
        e.Cell.Controls.Add(New LiteralControl(""))

        e.Cell.Controls.Add(LinkButton1)


        e.Cell.Controls.Add(dynamicTb)
        'Me.PlaceHolder1.Controls.Add(Calendar1)


    End Sub



    Public Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        Dim tb1 As TextBox
        ' tb1 = CType(Me.FindControl(1), TextBox)
        '  Label1.Text = tb1.Text

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim tb1 As TextBox
        tb1 = CType(Me.FindControl("testTb"), TextBox)
        Dim theText As String
        theText = tb1.Text

        '   DirectCast(GridView1.Rows(e.NewEditIndex).FindControl("txtDate"), TextBox)()
        ' tb1 = CType(Me.Calendar1.FindControl("1"), TextBox)
        tb1 = DirectCast(Calendar1.FindControl("1"), TextBox)
        Dim control1 As Control
        control1 = FindControl("1")


        'Label1.Text = tb1.Text

        Dim ctrl As Control
        Dim clr As Color

        For Each ctrl In Me.Calendar1.Parent.Controls

            If TypeOf ctrl Is TextBox Then

                CType(ctrl, TextBox).BackColor = Color.Red
            Else

                If ctrl.Controls.Count > 0 Then

                    '  SetTextBoxBackColor(ctrl, clr)

                End If

            End If

        Next

    End Sub
End Class

End Namespace
