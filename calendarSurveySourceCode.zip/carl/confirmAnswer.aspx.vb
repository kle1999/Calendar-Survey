﻿
Partial Class confirmAnswer
    Inherits System.Web.UI.Page

End Class
